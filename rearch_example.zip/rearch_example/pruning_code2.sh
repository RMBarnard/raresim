#!/bin/bash

pop=NFE
nsim=10000
pcase=120
rep=3
ncase=5000

cd /data001/projects/murphjes
#rm -rf raresim-rearch
conda activate
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ raresim==3.0.1rc2

#conda create --name raresim_env -c conda-forge python build numpy=2.1.0 pip=25.0.1 numba=0.61.0 setuptools=78.1.0 pandas=2.2.3 scipy=1.15.2
#git clone -b feat/raresim-rearch-v2 --single-branch https://github.com/RMBarnard/raresim.git raresim-rearch
#conda activate raresim_env
#cd raresim-rearch/
#python3 -m pip install -r requirements.txt
#python3 -m build

WD=${1:-/home/math/murphjes/example_code/rearch_example} # it defaults to the value it was hardcoded to before if you don't specify the first parameter

# create MAC bin estimates using target data stratified by functional status
python3 -m raresim calc \
    --mac ${WD}/MAC_bins_${nsim}.txt \
    -o ${WD}/MAC_bin_estimates_${nsim}_${pop}_${pcase}.txt \
    -N $nsim \
    --nvar_target_data ${WD}/chr19_block37_${pop}_nvar_target_data.txt \
    --afs_target_data ${WD}/chr19_block37_${pop}_AFS_target_data.txt \
    --w_fun 1.2 \
    --w_syn 1.2 \
    --reg_size 19.029

python3 -m raresim calc \
    --mac ${WD}/MAC_bins_${nsim}.txt \
    -o ${WD}/MAC_bin_estimates_${nsim}_${pop}_100.txt \
    -N $nsim \
    --nvar_target_data ${WD}/chr19_block37_${pop}_nvar_target_data.txt \
    --afs_target_data ${WD}/chr19_block37_${pop}_AFS_target_data.txt \
    --reg_size 19.029


# extract nsim individuals from the inital haplotype file
python3 -m raresim extract \
    -i ${WD}/chr19.block37.${pop}.sim${rep}.all.haps.gz \
    -o ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.haps.gz \
    -n $((2*$nsim)) \
    --seed $rep
 

# prune functional and synonymous variants down to pcase % functional / 100% synonymous and remove the rows of zeros (use the z flag)
python3 -m raresim sim \
    -m ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.haps-sample.gz \
    --functional_bins ${WD}/MAC_bin_estimates_${nsim}_${pop}_${pcase}_fun.txt \
    --synonymous_bins ${WD}/MAC_bin_estimates_${nsim}_${pop}_100_syn.txt \
    --stop_threshold 5 \
    -l ${WD}/chr19.block37.${pop}.sim${rep}.copy.legend \
    -L ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.legend \
    -H ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    -z

# DOESN'T PRODUCE A PRUNED-VARIANTS FILE


# extract the power cases for the same direction of effect scenario
python3 -m raresim extract \
    -i ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    -o ${WD}/chr19.block37.${pop}.sim${rep}.${ncase}.power.cases.same.${pcase}fun.100syn.haps.gz \
    -n $((2*$ncase)) \
    --seed $rep


# prune functional variants down to 100% in the entire sample
python3 -m raresim sim \
    -m ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    --f_only ${WD}/MAC_bin_estimates_${nsim}_${pop}_100_fun.txt \
    --stop_threshold 5 \
    -l ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.legend \
    -L ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.100fun.100syn.noz.legend \
    -H ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.100fun.100syn.noz.haps.gz

# PRUNED-VARIANTS FILE IS EMPTY EXCEPT FOR THE HEADER

python3 -m raresim sim \
    -m ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    --f_only ${WD}/MAC_bin_estimates_${nsim}_${pop}_100_fun.txt \
    --stop_threshold 5 \
    -l ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.legend \
    -L ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.100fun.100syn.legend \
    -H ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.100fun.100syn.haps.gz \
    -z

# DOESN'T PRODUCE A PRUNED-VARIANTS FILE

# record the pruned variants (make sure to account for the header or lack thereof)
awk -F'\t' -v OFS='\t' 'NR==FNR {if (FNR > 1) ids[$1]=1; next} FNR==1 {print $0, "protected"; next} {print $0, ($1 in ids) ? 1 : 0}' \
${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.100fun.100syn.noz.legend-pruned-variants \
${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.legend > ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.protected.legend 


# extract the type I error cases (and power cases for the opposite direction of effect scenario)
python3 -m raresim extract \
    -i ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.100fun.100syn.haps.gz \
    -o ${WD}/chr19.block37.${pop}.sim${rep}.${ncase}.t1e.cases.100fun.100syn.haps.gz \
    -n $((2*$ncase)) \
    --seed $rep


# prune functional variants down to 100% in the entire sample again excluding the previously pruned variants from the entire sample
python3 -m raresim sim \
    -m ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    --f_only ${WD}/MAC_bin_estimates_${nsim}_${pop}_100_fun.txt \
    --stop_threshold 5 \
    -l ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.protected.legend \
    -L ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.opp.100fun.100syn.noz.legend \
    -H ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.opp.100fun.100syn.noz.haps.gz \
    --keep_protected \
    --verbose

# VERBOSE DOESN'T DO ANYTHINGD DIFFERENT - could be because the protected column in the legend file is all 0s

awk -F'\t' '$10 == "1" {count++} END {print count}' ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.protected.legend # 112
awk -F'\t' '$10 == "1" {count++} END {print count}' ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.opp.100fun.100syn.noz.legend-pruned-variants # 0

python3 -m raresim sim \
    -m ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.${pcase}fun.100syn.haps.gz \
    --f_only ${WD}/MAC_bin_estimates_${nsim}_${pop}_100_fun.txt \
    --stop_threshold 5 \
    -l ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.${pcase}fun.100syn.protected.legend \
    -L ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.opp.100fun.100syn.legend \
    -H ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.opp.100fun.100syn.haps.gz \
    --keep_protected \
    --verbose \
    -z 

awk -F'\t' '$10 == "1" {count++} END {print count}' ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.opp.100fun.100syn.legend # 112
awk -F'\t' '$10 == "1" {count++} END {print count}' ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.opp.100fun.100syn.legend-pruned-variants # 0

zcat ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.opp.100fun.100syn.haps.gz | wc -l


# extract the controls for the opposite direction of effect scenario
python3 -m raresim extract \
    -i ${WD}/chr19.block37.${pop}.sim${rep}.${nsim}.all.opp.100fun.100syn.haps.gz \
    -o ${WD}/chr19.block37.${pop}.sim${rep}.${ncase}.controls.opp.100fun.100syn.haps.gz \
    -n $((2*$ncase)) \
    --seed $rep



# power cases (same): chr19.block37.${pop}.sim${rep}.${ncase}.power.cases.same.${pcase}fun.100syn.haps-sample.gz
# type I error cases & power cases (opp): chr19.block37.${pop}.sim${rep}.${ncase}.t1e.cases.100fun.100syn.haps-sample.gz
# controls (same): chr19.block37.${pop}.sim${rep}.${ncase}.t1e.cases.100fun.100syn.haps-remainder.gz
# controls (opp): chr19.block37.${pop}.sim${rep}.${ncase}.controls.opp.100fun.100syn.haps-remainder.gz
